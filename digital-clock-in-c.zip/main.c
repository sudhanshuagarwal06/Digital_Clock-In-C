#include <stdio.h>
#include <conio.h>
#include <time.h>

int
main ()
{
  int h, m, s;
  printf ("Enter Current Time Like Hours,Minute,Second\n");

  scanf ("%d", &h);
  scanf ("%d", &m);
  scanf ("%d", &s);

  int date, month, year;
  printf ("Enter Current Date Like Date,Month,Year\n");

  scanf ("%d", &date);
  scanf ("%d", &month);
  scanf ("%d", &year);

  while (1)
    {
      if (s >= 60)
	{
	  m++;
	  s = 0;
	}
      if (m >= 60)
	{
	  h++;
	  m = 0;
	}
      if (h >= 24)
	{
	  h = 0;
	  m = 0;
	  s = 0;
	  date++;
	}
      if (((year % 4 == 0) && (year % 100 != 0)) || (year % 400 == 0))
	{
	  if (date == 32 && month == 1)
	    {
	      date = 1;
	      month = 2;
	    }
	  else if (date == 30 && month == 2)
	    {
	      date = 1;
	      month = 3;
	    }
	  else if (date == 32 && month == 3)
	    {
	      date = 1;
	      month = 4;
	    }
	  else if (date == 31 && month == 4)
	    {
	      date = 1;
	      month = 5;
	    }
	  else if (date == 32 && month == 5)
	    {
	      date = 1;
	      month = 6;
	    }
	  else if (date == 30 && month == 6)
	    {
	      date = 1;
	      month = 7;
	    }
	  else if (date == 32 && month == 7)
	    {
	      date = 1;
	      month = 8;
	    }
	  else if (date == 32 && month == 8)
	    {
	      date = 1;
	      month = 9;
	    }
	  else if (date == 31 && month == 9)
	    {
	      date = 1;
	      month = 10;
	    }
	  else if (date == 32 && month == 10)
	    {
	      date = 1;
	      month = 11;
	    }
	  else if (date == 31 && month == 11)
	    {
	      date = 1;
	      month = 12;
	    }
	  else if (date == 32 && month == 12)
	    {
	      date = 1;
	      month = 1;
	      year++;
	    }

	}
      else
	{

	  if (date == 32 && month == 1)
	    {
	      date = 1;
	      month = 2;
	    }
	  else if (date == 29 && month == 2)
	    {
	      date = 1;
	      month = 3;
	    }
	  else if (date == 32 && month == 3)
	    {
	      date = 1;
	      month = 4;
	    }
	  else if (date == 31 && month == 4)
	    {
	      date = 1;
	      month = 5;
	    }
	  else if (date == 32 && month == 5)
	    {
	      date = 1;
	      month = 6;
	    }
	  else if (date == 30 && month == 6)
	    {
	      date = 1;
	      month = 7;
	    }
	  else if (date == 32 && month == 7)
	    {
	      date = 1;
	      month = 8;
	    }
	  else if (date == 32 && month == 8)
	    {
	      date = 1;
	      month = 9;
	    }
	  else if (date == 31 && month == 9)
	    {
	      date = 1;
	      month = 10;
	    }
	  else if (date == 32 && month == 10)
	    {
	      date = 1;
	      month = 11;
	    }
	  else if (date == 31 && month == 11)
	    {
	      date = 1;
	      month = 12;
	    }
	  else if (date == 32 && month == 12)
	    {
	      date = 1;
	      month = 1;
	      year++;
	    }
	}


      int pq = 0;
      for (int i = 1; i < year; i++)
	{
	  if (((i % 4 == 0) && (i % 100 != 0)) || (i % 400 == 0))
	    {
	      pq = pq + 366;
	    }
	  else
	    {
	      pq = pq + 365;
	    }
	}
      if (((year % 4 == 0) && (year % 100 != 0)) || (year % 400 == 0))
	{
	  for (int i = 1; i < month; i++)
	    {
	      if (i == 1)
		{
		  pq = pq + 31;
		}
	      else if (i == 2)
		{
		  pq = pq + 29;
		}
	      else if (i == 3)
		{
		  pq = pq + 31;
		}
	      else if (i == 4)
		{
		  pq = pq + 30;
		}
	      else if (i == 5)
		{
		  pq = pq + 31;
		}
	      else if (i == 6)
		{
		  pq = pq + 30;
		}
	      else if (i == 7)
		{
		  pq = pq + 31;
		}
	      else if (i == 8)
		{
		  pq = pq + 31;
		}
	      else if (i == 9)
		{
		  pq = pq + 30;
		}
	      else if (i == 10)
		{
		  pq = pq + 31;
		}
	      else if (i == 11)
		{
		  pq = pq + 30;
		}
	      else if (i == 12)
		{
		  pq = pq + 31;
		}
	    }
	}
      else
	{
	  for (int i = 1; i < month; i++)
	    {
	      if (i == 1)
		{
		  pq = pq + 31;
		}
	      else if (i == 2)
		{
		  pq = pq + 28;
		}
	      else if (i == 3)
		{
		  pq = pq + 31;
		}
	      else if (i == 4)
		{
		  pq = pq + 30;
		}
	      else if (i == 5)
		{
		  pq = pq + 31;
		}
	      else if (i == 6)
		{
		  pq = pq + 30;
		}
	      else if (i == 7)
		{
		  pq = pq + 31;
		}
	      else if (i == 8)
		{
		  pq = pq + 31;
		}
	      else if (i == 9)
		{
		  pq = pq + 30;
		}
	      else if (i == 10)
		{
		  pq = pq + 31;
		}
	      else if (i == 11)
		{
		  pq = pq + 30;
		}
	      else if (i == 12)
		{
		  pq = pq + 31;
		}
	    }
	}
      pq = pq + date;
      int v = pq % 7;

      clrscr ();

      if (v == 1)
	{
	  printf ("           Digital Clock         \n");
	  printf ("         Time:- %d:%d:%d          \n", h, m, s);
	  printf ("         Date:- %d-%d-%d (Mon)          \n", date, month,
		  year);
	}
      else if (v == 2)
	{
	  printf ("           Digital Clock         \n");
	  printf ("         Time:- %d:%d:%d          \n", h, m, s);
	  printf ("         Date:- %d-%d-%d (Tus)         \n", date, month,
		  year);
	}
      else if (v == 3)
	{
	  printf ("           Digital Clock         \n");
	  printf ("         Time:- %d:%d:%d          \n", h, m, s);
	  printf ("         Date:- %d-%d-%d (Wed)         \n", date, month,
		  year);
	}
      else if (v == 4)
	{
	  printf ("           Digital Clock         \n");
	  printf ("         Time:- %d:%d:%d          \n", h, m, s);
	  printf ("         Date:- %d-%d-%d (Thu)         \n", date, month,
		  year);
	}
      else if (v == 5)
	{
	  printf ("           Digital Clock         \n");
	  printf ("         Time:- %d:%d:%d          \n", h, m, s);
	  printf ("         Date:- %d-%d-%d (Fri)         \n", date, month,
		  year);
	}
      else if (v == 6)
	{
	  printf ("           Digital Clock         \n");
	  printf ("         Time:- %d:%d:%d          \n", h, m, s);
	  printf ("         Date:- %d-%d-%d (Sat)         \n", date, month,
		  year);
	}
      else if (v == 7)
	{
	  printf ("           Digital Clock         \n");
	  printf ("         Time:- %d:%d:%d          \n", h, m, s);
	  printf ("         Date:- %d-%d-%d (Sun)         \n", date, month,
		  year);
	}

      sleep (1);
      s++;

    }

  return 0;
}
